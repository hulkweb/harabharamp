<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="Ansonika">
<title>MPBJYM </title>

<!-- Favicons-->
<link rel="shortcut icon" href="/assets/admin/img/favicon.png" type="image/png">


<!-- Bootstrap core CSS-->
<link href="/assets/admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!-- Main styles -->
<link href="/assets/admin/css/admin.css" rel="stylesheet">
<!-- Icon fonts-->
<link href="/assets/admin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<!-- Plugin styles -->
<link href="/assets/admin/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
<!-- Your custom styles -->
<link href="/assets/admin/css/custom.css" rel="stylesheet">
<link href="/assets/admin/css/date_picker.css" rel="stylesheet">
<link href="/assets/admin/vendor/dropzone.css" rel="stylesheet">

<!-- WYSIWYG Editor -->
<link rel="stylesheet" href="/assets/admin/js/editor/summernote-bs4.css">
<?php /**PATH /home/chhavini/mpbjym.chhavinirman.in/resources/views/partials/head.blade.php ENDPATH**/ ?>