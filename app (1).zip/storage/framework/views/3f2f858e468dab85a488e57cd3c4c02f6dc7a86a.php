

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Add Setting</li>
        </ol>
        <form action="<?php echo e(route('setting_update')); ?>" method="post" enctype="multipart/form-data">
            <div class="box_general padding_bottom">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-5">
                        <div class="header_box version_2">
                            <h2><i class="fa fa-file"></i> Update Setting</h2>
                        </div>
                        <br>
                        <div class="form-group">
                            <label>Setting Name </label>
                            <input type="text" name="property" class="form-control" value="<?php echo e($setting->property); ?>" >
                            <input type="hidden" name="id" value="<?php echo e($setting->id); ?>">
                        </div>
                        <div class="form-group">
                            <label>Setting Value </label>
                            <input type="text" name="value" class="form-control" value="<?php echo e($setting->value); ?>" >
                        </div>

                        <p><button type="submit" class="btn_1 medium">Save</button></p>

                    </div>

                </div>

        </form>
    </div>
    <!-- /.container-fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chhavini/mpbjym.chhavinirman.in/resources/views/admin/setting_edit.blade.php ENDPATH**/ ?>