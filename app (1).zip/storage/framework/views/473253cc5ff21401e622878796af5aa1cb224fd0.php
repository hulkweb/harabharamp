
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Members</li>
        </ol>
        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i class="fa fa-table"></i> Members
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr> <th>Num</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Position</th>
                                <th>Place</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                      <td><?php echo e($i +1); ?></td>
                                    <td><?php echo e($member->name); ?></td>
                                    <td><?php echo e($member->email); ?></td>
                                    <td><?php echo e($member->phone); ?></td>
                                    <td><?php echo e($member->position->title); ?></td>
                                    <td><?php echo e($member->place); ?></td>
                                    <td><?php echo e(date("d M Y ",$member->created_at)); ?></td>
                                    <td>
                                        <a href="/admin/member_edit/<?php echo e($member->id); ?>" class="btn btn-primary">Update</a>

                                        <a href="/admin/member_delete/<?php echo e($member->id); ?>"
                                            class="btn btn-sm btn-danger">Delete</a>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- /tables-->
    </div>
    <!-- /container-fluid-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chhavini/mpbjym.chhavinirman.in/resources/views/admin/members.blade.php ENDPATH**/ ?>