
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="header-container responsive">
            <h1>
                विधानसभा
            </h1>


        </div>

        <div class="row">

            <div class="col-sm-5  card">
                <form method="post" action="<?php echo e(route('parliament_store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="method">विधानसभा</label>
                        <input type="text" name="title" class="form-control" autofocus>
                    </div>

                    <div class="form-group">
                        <button class="btn btn-primary">Create</button>
                    </div>
                </form>
            </div>
            <div class="col-sm-6 offset-sm-1 p-4 card">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Num</th>
                            <th>Name</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $parliaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parliament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($parliament->id); ?></td>
                                <td><?php echo e($parliament->title); ?></td>
                                <td> <a class="btn btn-danger m-1" href="/admin/parliament_delete/<?php echo e($parliament->id); ?>"> <i
                                            class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>


        </div>




    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/chhavini/mpbjym.chhavinirman.in/resources/views/admin/parliaments.blade.php ENDPATH**/ ?>